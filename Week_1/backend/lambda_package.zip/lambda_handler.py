from mangum import Mangum
from main import app

# Mangum wraps FastAPI/ASGI app for AWS Lambda + API Gateway
handler = Mangum(app, lifespan="off")
